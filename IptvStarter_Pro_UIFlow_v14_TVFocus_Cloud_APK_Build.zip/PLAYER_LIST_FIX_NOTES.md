# IPTV Starter Pro - Player ve Liste Düzeltmeleri v5

Bu sürümde:

- Kanal tıklamasında uygulamanın kapanmaması için PlayerActivity güvenli başlatma yapısına alındı.
- Geçersiz / bozuk yayın linkinde uygulama kapanmaz; player ekranında hata mesajı gösterir.
- M3U linklerinde `|` sonrası header bilgileri player URI'sinden ayrıştırılır.
- Kanal listesi ve kaynak listesi görünür scroll bar ile kaydırılabilir hale getirildi.
- Kanal satırlarında sadece kanal adı gösterilir.
- Kaynak listesinde sadece link/kaynak adı gösterilir.
- Kaynak işlemleri için kaynak adına uzun basılır: Yenile, Düzelt, Sil.

Not: Yayın linkinin kapalı, süresi dolmuş veya cihazda desteklenmeyen formatta olması durumunda player hata gösterir; bu artık uygulamayı kapatmamalıdır.


## v6 ekleri

- Player alt barındaki sağ/sol düğmeler artık 10 sn sarma yerine önceki/sonraki kanala geçer.
- Kumandada sol/sağ yön tuşları ve kanal +/- tuşları kanal değiştirme için bağlandı.
- Hızlı sarma medya kumandasındaki REW/FWD tuşlarında korunur.
- Player yatay ekranda kenar boşluğu bırakmadan `RESIZE_MODE_FILL` ile tam ekrana yayılır.
- Ana ekran üst boşlukları azaltıldı; kaynak alanı daha kısa, kanal listesi daha geniş bırakıldı.
- 2'li ve 4'lü ekran seçenekleri eklendi; seçili kaynaktan ilk 2/4 kanal çoklu izleme ekranında açılır.
- Çoklu ekranda ilk kanal sesli, diğerleri sessiz başlar; ekrana tıklayınca o pencerenin sesi açılır.
