# GitHub ZIP'ten v12 APK üretme

Repo içine şu ZIP dosyasını tek dosya olarak yükleyin:

```text
IptvStarter_Pro_UIFlow_v12_Wuffy_Cloud_APK_Build.zip
```

Sonra şu dosyayı oluşturun:

```text
.github/workflows/build-v12-from-zip.yml
```

İçine şunu yapıştırın:

```yaml
name: Build v12 APK From ZIP

on:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout repo
        uses: actions/checkout@v4

      - name: Unzip project
        run: |
          unzip IptvStarter_Pro_UIFlow_v12_Wuffy_Cloud_APK_Build.zip -d project
          find project -maxdepth 3 -type f | head -80

      - name: Find project root
        run: |
          PROJECT_DIR=$(find project -name "settings.gradle.kts" -exec dirname {} \; | head -1)
          echo "PROJECT_DIR=$PROJECT_DIR" >> $GITHUB_ENV
          echo "Project root: $PROJECT_DIR"

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 17

      - name: Set up Android SDK
        uses: android-actions/setup-android@v3

      - name: Install Android SDK packages
        run: |
          yes | sdkmanager --licenses
          sdkmanager "platforms;android-35" "build-tools;35.0.0" "platform-tools"

      - name: Create Gradle wrapper if missing
        working-directory: ${{ env.PROJECT_DIR }}
        run: |
          if [ ! -f ./gradlew ]; then
            gradle wrapper --gradle-version 8.9
          fi
          chmod +x ./gradlew

      - name: Build debug APK
        working-directory: ${{ env.PROJECT_DIR }}
        run: ./gradlew assembleDebug --stacktrace

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: IPTV-Starter-v12-Wuffy-Debug-APK
          path: ${{ env.PROJECT_DIR }}/app/build/outputs/apk/debug/*.apk
```

Sonra GitHub'da:

```text
Actions > Build v12 APK From ZIP > Run workflow
```
