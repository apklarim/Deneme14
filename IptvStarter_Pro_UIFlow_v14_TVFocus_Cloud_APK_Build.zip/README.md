# IPTV Starter Pro v6

Bu paket TV, TV Box, tablet ve telefon için geliştirilmiş IPTV Player başlangıç projesidir.

## Bu sürümde eklenenler

- Player alt barındaki ileri/geri düğmeleri artık kanal değiştirir.
- Kumanda sol/sağ, kanal +/- ve medya önceki/sonraki tuşları kanal geçişi için desteklenir.
- Media rewind/fast-forward tuşlarında 10 saniye sarma korunur.
- Yatay ekranda player tam ekran ve kenarsız çalışır.
- Ana ekran üst bölüm daha kompakt hale getirildi; kanal listesine daha fazla alan bırakıldı.
- 2'li ve 4'lü çoklu ekran seçenekleri eklendi.
- Çoklu ekranda seçili kaynağın ilk 2 veya 4 kanalı açılır. İlk kanal sesli, diğerleri sessiz başlar; pencereye tıklayınca o pencerenin sesi açılır.
- M3U URL, M3U dosya, Xtream ve MAG kaynak yönetimi korunur.
- Uzun kanal listelerinde RecyclerView + DiffUtil kullanılır.

## APK üretme

Android Studio'da:

1. Proje klasörünü açın.
2. Gradle JDK olarak Embedded JDK 17 seçin.
3. File > Sync Project with Gradle Files.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

APK yolu:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Not

Uygulama yalnızca kullanıcının yasal erişimi olan yayın kaynaklarıyla kullanılmalıdır.
MAG bölümü portal bilgisini kaydeder; gerçek Stalker/MAG kanal çekme entegrasyonu ayrı aşamada genişletilebilir.


## v8
Ayarlar M3U / Xtream / MAG sekmelerine ayrıldı, yanlış linkte eski kayıt korunur, Xtream formatı algılanır, player içinde grup/kanal menüsü ve resimli kanal listesi iyileştirildi.

## v12 Wuffy destekli otomatik player

Ayarlar ekranındaki `▶ Player` butonundan player seçimi yapılabilir.
Varsayılan öneri `Otomatik`tir. Otomatik modda yayın önce dahili ExoPlayer ile denenir; hata alınırsa Wuffy Player açılır. Wuffy yüklü değilse Android'in harici player seçimi açılır.

Wuffy paket adı: `co.wuffy.player`.
