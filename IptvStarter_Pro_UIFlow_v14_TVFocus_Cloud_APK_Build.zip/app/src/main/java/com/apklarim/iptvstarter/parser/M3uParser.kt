package com.apklarim.iptvstarter.parser

class M3uParser {
    private val logoRegex = Regex("tvg-logo=\"([^\"]*)\"")
    private val groupRegex = Regex("group-title=\"([^\"]*)\"")
    private val tvgNameRegex = Regex("tvg-name=\"([^\"]*)\"")

    fun parse(content: String): List<IptvChannel> {
        val channels = ArrayList<IptvChannel>(4096)
        val seenUrls = HashSet<String>(4096)
        var currentName = "Kanal"
        var currentLogo: String? = null
        var currentGroup: String? = null

        content.lineSequence().forEach { raw ->
            val line = raw.trim()
            if (line.isEmpty()) return@forEach
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    val nameAfterComma = line.substringAfterLast(',', missingDelimiterValue = "").trim()
                    val tvgName = tvgNameRegex.find(line)?.groupValues?.getOrNull(1)
                    currentName = nameAfterComma.ifBlank { tvgName ?: "Kanal" }
                    currentLogo = logoRegex.find(line)?.groupValues?.getOrNull(1)?.ifBlank { null }
                    currentGroup = groupRegex.find(line)?.groupValues?.getOrNull(1)?.ifBlank { null }
                }
                isMediaUrl(line) && seenUrls.add(line) -> {
                    channels += IptvChannel(
                        name = currentName,
                        logo = currentLogo,
                        group = currentGroup,
                        streamUrl = line,
                        mediaType = detectMediaType(line, currentGroup)
                    )
                    currentName = "Kanal"
                    currentLogo = null
                    currentGroup = null
                }
            }
        }
        return channels
    }

    private fun isMediaUrl(line: String): Boolean =
        line.startsWith("http://", true) ||
        line.startsWith("https://", true) ||
        line.startsWith("rtmp://", true) ||
        line.startsWith("rtsp://", true)

    private fun detectMediaType(url: String, group: String?): String {
        val value = (url + " " + (group ?: "")).lowercase()
        return when {
            "/series/" in value || "dizi" in value || "series" in value || "sezon" in value || "season" in value -> "SERIES"
            "/movie/" in value || "/vod/" in value || value.endsWith(".mp4") || value.endsWith(".mkv") ||
                "film" in value || "movie" in value || "sinema" in value || "vod" in value -> "VOD"
            else -> "LIVE"
        }
    }
}
