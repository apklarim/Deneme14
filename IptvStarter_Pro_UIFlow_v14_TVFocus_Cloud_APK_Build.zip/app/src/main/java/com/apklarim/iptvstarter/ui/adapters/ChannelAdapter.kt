package com.apklarim.iptvstarter.ui.adapters

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.apklarim.iptvstarter.data.local.ChannelEntity
import com.apklarim.iptvstarter.ui.dp

class ChannelAdapter(
    private val onClick: (ChannelEntity) -> Unit
) : ListAdapter<ChannelEntity, ChannelAdapter.ChannelViewHolder>(Diff) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
        val row = LinearLayout(parent.context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            isFocusable = true
            isClickable = true
            setPadding(dp(18), dp(14), dp(18), dp(14))
            layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(dp(6), dp(5), dp(10), dp(5))
            }
        }
        return ChannelViewHolder(row, onClick)
    }

    override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) = holder.bind(getItem(position))

    class ChannelViewHolder(
        private val root: LinearLayout,
        private val onClick: (ChannelEntity) -> Unit
    ) : RecyclerView.ViewHolder(root) {
        private val title = TextView(root.context).apply {
            setTextColor(Color.WHITE)
            textSize = 17f
            maxLines = 1
            typeface = Typeface.DEFAULT_BOLD
        }

        init {
            root.addView(title)
        }

        fun bind(channel: ChannelEntity) {
            title.text = channel.name.ifBlank { "İsimsiz Kanal" }
            root.background = GradientDrawable().apply {
                cornerRadius = root.dp(16).toFloat()
                setColor(Color.rgb(12, 25, 43))
                setStroke(root.dp(1), Color.rgb(32, 50, 75))
            }
            root.setOnClickListener { onClick(channel) }
        }
    }

    object Diff : DiffUtil.ItemCallback<ChannelEntity>() {
        override fun areItemsTheSame(oldItem: ChannelEntity, newItem: ChannelEntity) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: ChannelEntity, newItem: ChannelEntity) = oldItem == newItem
    }
}
