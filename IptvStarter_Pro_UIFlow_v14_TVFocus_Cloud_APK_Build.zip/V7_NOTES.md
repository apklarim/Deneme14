# IPTV Starter Pro v7

Bu sürüm çalışan v6 üzerine yapılmıştır.

## Değişiklikler

- Ana ekran sadeleştirildi: Canlı, Film, Dizi butonları eklendi.
- Sağ üst köşeye Ayarlar butonu eklendi.
- M3U Link, M3U Dosya, Xtream, MAG, 2li ve 4lü ekran seçenekleri Ayarlar ekranına taşındı.
- Linke dokununca player otomatik açılır.
- Eski ana ekran kanal listesi kaldırıldı. Kanal/grup seçimi player içine alındı.
- Player ekranında çift dokunma / çift tıklama ile grup menüsü açılır.
- Grup seçilince kanallar kayar liste olarak görünür. Kanal seçilince liste kapanır ve player oynatır.
- Kumanda / air kumanda için yukarı-aşağı tuşları kanal değiştirir. Eski sol-sağ kanal değiştirme kaldırıldı.
- Player içinde 2li ve 4lü ekran kısayolları eklendi.
- Kanal listesinde uzun basınca uygulama içi player / alternatif harici player seçeneği çıkar.
- Çıkış için geri tuşuna peş peşe basınca Evet / Hayır sorusu eklenmiştir.
- 3D görünümlü basit uygulama logosu eklendi.
- Görsel renkler daha koyu ve göz yormayan tona çekildi.

## Notlar

APK bu ortamda derlenemediği için Android Studio üzerinden Build APK alınmalıdır.
