# v13 Notes

- 2'li ve 4'lü player ekranlarında grup panel genişliği artırıldı; liste artık daha rahat kaydırılır.
- Kanal/grup listesi açıkken kumanda yukarı-aşağı tuşları artık kanal değiştirmez; listede gezinmeye bırakılır.
- Player ekranındayken yukarı-aşağı kanal değiştirme devam eder.
- Player alt hızlı çubuğundaki sağ-sol kanal butonları kanal değiştirme için kullanılır.
- Gizliler butonu kaldırıldı.
- Herhangi bir açık gruba uzun basınca grup gizleme/gösterme çoklu seçim ekranı açılır.
- Şifreli/adult grup açılırken PIN sorulur; doğru girilirse açılır.
- Tekli, 2'li ve 4'lü ekranda son grup/kanal listesi mantığı korunur.
