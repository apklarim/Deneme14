# v9 Kullanım Akışı Güncellemesi

Bu sürüm v8 üzerine hazırlanmıştır.

## Yapılanlar

- Player çift tık/OK çift basma davranışı artık en son seçilen gruptaki kanal listesinde kalır.
- Grup listesine dönmek için player hızlı çubuğunda `Gruplar`, kanal panelinde `← Gruplar` seçeneği eklendi.
- Canlı / Film / Dizi ayrımı artık medya tipine göre filtrelenir:
  - Canlı: `LIVE`
  - Film: `VOD`
  - Dizi: `SERIES`
- Player hızlı çubuğuna `PIP` seçeneği eklendi. Android 8+ cihazlarda çalışır.
- Kumanda/air mouse gezinme rengi daha okunur turuncu/altın tona çekildi.
- Player kanal listesinde fokus rengi belirginleştirildi.
- Kanal satırlarına kanal numarası eklendi.
- Kumandadan rakam girerek kanal seçme eklendi. Örneğin `1` → 1. kanal, `12` → 12. kanal.
- Geri tuşu kanal listesindeyken önce grup listesine döner; grup listesindeyken player’a döner.

## Not

PIP cihaz/Android sürümü ve üretici ROM izinlerine bağlıdır. Android 8 ve üstünde `supportsPictureInPicture` etkinleştirilmiştir.
