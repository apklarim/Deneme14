# v14 - TV Focus + Group Select Fix

- Otomatik player modunda harici player seçimi kaldırıldı.
- Otomatik mod artık dahili ExoPlayer dener; olmazsa Wuffy Player dener. Wuffy yoksa hata gösterir.
- Ayarlar > Player menüsünden Harici Player seçeneği kaldırıldı.
- Kanal uzun basma menüsünden Harici player seçeneği kaldırıldı.
- Grup gizle/göster çoklu seçim ekranına en üste "Hepsini seç / temizle" seçeneği eklendi.
- Tekli player ve 2'li/4'lü player gizle/göster ekranları aynı davranır.
- TV/TV Box link ekleme bölümünde kumanda/air mouse odak geçiş sırası daha düzenli hale getirildi.
- Buton geçişlerinde focus rengi korunarak seçili buton daha belirgin gösterilir.
