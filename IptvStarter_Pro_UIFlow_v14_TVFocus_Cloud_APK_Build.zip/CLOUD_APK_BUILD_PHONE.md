# Bilgisayar olmadan APK alma yöntemi

Bu projede GitHub Actions ile APK üretmek için hazır workflow eklidir.

## Telefonda/tablette yapılacaklar

1. GitHub uygulamasını veya github.com sitesini aç.
2. Yeni bir repository oluştur. Örnek ad: `iptv-starter-pro`.
3. Bu ZIP'in içindeki proje dosyalarını repository'ye yükle. En önemli klasörler/dosyalar:
   - `.github/workflows/build-debug-apk.yml`
   - `app/`
   - `build.gradle.kts`
   - `settings.gradle.kts`
   - `gradle.properties`
4. Repository sayfasında **Actions** sekmesine gir.
5. **Build Debug APK** workflow'unu seç.
6. **Run workflow** düğmesine bas.
7. İşlem bitince aynı workflow çalışmasının altındaki **Artifacts** bölümünden APK'yı indir.
8. İnen ZIP'in içinden `app-debug.apk` dosyasını çıkarıp telefona/tablete kur.

## Notlar

- Bu APK debug APK'dır; test için uygundur.
- Telefon kurulumda "Bilinmeyen uygulamaları yükle" izni isteyebilir.
- Build kırmızı hata verirse GitHub Actions logundaki ilk kırmızı hata satırını gönder.
